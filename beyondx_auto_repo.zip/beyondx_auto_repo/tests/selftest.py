#!/usr/bin/env python3
"""
Basic self‑test for make_twrp_tar.py. It creates a dummy image file, runs
the tar packaging script twice and verifies that the resulting `.tar.md5`
file ends with the correct MD5 of the tar contents on both runs. If any
check fails, the script exits with a non‑zero status.
"""

import hashlib
import os
import subprocess
import sys
import tempfile

def run_test() -> None:
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)
        # Create a dummy image file with random data
        dummy_path = os.path.join(tmpdir, "dummy.img")
        with open(dummy_path, "wb") as f:
            f.write(os.urandom(4096))

        # Path to the script under test
        script_path = os.path.join(os.path.dirname(__file__), '..', 'scripts', 'make_twrp_tar.py')
        script_path = os.path.abspath(script_path)

        # Run the packaging script twice to ensure determinism
        for i in range(2):
            subprocess.run([sys.executable, script_path, dummy_path], check=True)
            tar_name = "TWRP_beyondx.tar"
            tar_md5_name = tar_name + ".md5"
            # Compute the MD5 of the tar archive (excluding footer)
            with open(tar_name, "rb") as ftar:
                tar_data = ftar.read()
            expected_md5 = hashlib.md5(tar_data).hexdigest().encode()
            # Read the combined tar+md5 file
            with open(tar_md5_name, "rb") as fmd5:
                combined = fmd5.read()
            # Check that the last 32 bytes are the hex digest
            if not combined.endswith(expected_md5):
                raise SystemExit(f"[FAIL] Run {i+1}: MD5 footer mismatch")
            else:
                print(f"[PASS] Run {i+1}: tar.md5 has correct MD5 footer")

if __name__ == '__main__':
    run_test()