# beyondx TWRP Auto Patch Repository

This repository automates the process of patching the Samsung Galaxy S10 5G
(`beyondx`) recovery image to add **fastbootd** support, cleaning the fstab
entries, converting a TWRP image into an Odin‑flashable TAR archive, and
provides helper scripts to flash a Generic System Image (GSI) or update
TWRP directly from the device. It is designed to be self‑contained: you
only need your stock `recovery.img` (decompressed, not `.lz4`) and a
TWRP image for your device.

## Contents

| File/Directory | Description |
| --- | --- |
| `scripts/patch_local.sh` | Wrapper script that patches a recovery image using `script1.sh` and `script2.sh`. Downloads the `magiskboot` binary automatically. Produces `patched_recovery.img`. |
| `scripts/script1.sh` | Adds **fastbootd** support to a recovery image. Based on the script from [Streep69/Patch‑Recovery](https://github.com/Streep69/Patch-Recovery). |
| `scripts/script2.sh` | Cleans AVB/verify flags from fstab entries in the recovery image. |
| `scripts/make_twrp_tar.py` | Converts a TWRP `.img` into `TWRP_beyondx.tar.md5` suitable for flashing with Odin. |
| `scripts/flash_gsi_linux.sh` | Example script to flash a GSI from **fastbootd** on Linux/macOS. |
| `scripts/flash_from_twrp.sh` | Flash a new TWRP image from within TWRP using `dd` on the device. |
| `inputs/` | Placeholder directory. Drop your `recovery.img` and `twrp.img` here if you wish to commit them before running CI. |
| `tests/selftest.py` | Simple test verifying that `make_twrp_tar.py` produces a valid Odin `.tar.md5` file. |

## Usage

### 1. Patch your stock recovery

1. Ensure your stock recovery image is **decompressed**. If you have a
   `.lz4` file, decompress it on your computer first using `lz4 -d`.
2. Run the patch script to produce a patched recovery image:

   ```bash
   bash scripts/patch_local.sh /path/to/recovery.img
   ```

   After it finishes you will have `patched_recovery.img` in the current
   directory. This image has fastbootd enabled and its fstab cleaned.

3. (Optional) If you need an Odin package, compress the patched image
   into a TAR with an MD5 footer:

   ```bash
   tar -cf Recovery.tar patched_recovery.img
   md5sum Recovery.tar | awk '{print $1}' >> Recovery.tar
   ```

### 2. Convert a TWRP image into an Odin TAR

Run the Python helper to generate a tar archive with a proper MD5 footer. You
need Python 3 installed:

```bash
python3 scripts/make_twrp_tar.py /path/to/twrp.img
# Result: TWRP_beyondx.tar and TWRP_beyondx.tar.md5
```

Flash `TWRP_beyondx.tar.md5` via Odin in the **AP** slot.

### 3. Flash a GSI from fastbootd

Once you have patched recovery installed, boot into **fastbootd** from
recovery (recovery → “Enter fastboot”). Then flash your GSI:

```bash
./scripts/flash_gsi_linux.sh /path/to/your-gsi.img
```

This script erases the existing system, flashes the GSI, performs a factory
reset and reboots.

### 4. Update TWRP from within TWRP

If you are already in TWRP and want to flash another TWRP image without a
computer, push the new image to your device (e.g. `/sdcard/Download`) and
run:

```sh
sh /path/to/scripts/flash_from_twrp.sh /sdcard/Download/twrp.img
```

This uses `dd` to write the image to the recovery partition and reboots
back into recovery.

## Notes

- These scripts are provided as‑is and should be used on devices you own.
- Always back up your original images before flashing or modifying them.
- The patch process uses the open‑source `magiskboot` tool from the
  [Patch‑Recovery](https://github.com/Streep69/Patch-Recovery) project.