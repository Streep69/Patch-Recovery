#!/usr/bin/env bash
# Patch a Samsung recovery image locally to enable fastbootd and clean
# verification flags. This script wraps the fastbootd patch (script1.sh)
# and fstab cleaner (script2.sh) and downloads the magiskboot binary
# automatically from the upstream repository. A patched recovery image
# named patched_recovery.img will be created in the current working
# directory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 path/to/recovery.img"
  exit 1
fi

REC="$1"

if [ ! -f "$REC" ]; then
  echo "Input file not found: $REC"
  exit 1
fi

# Create a temporary working directory
WORKDIR=$(mktemp -d)

# Copy the input recovery image into the working directory as recovery.img
cp "$REC" "$WORKDIR/recovery.img"

# Copy patch scripts into the working directory
cp "$SCRIPT_DIR/script1.sh" "$WORKDIR/"
cp "$SCRIPT_DIR/script2.sh" "$WORKDIR/"

# Change into the working directory
cd "$WORKDIR"

# Download magiskboot from the upstream repository. This binary is used
# by the patch scripts to unpack and repack the recovery image. If the
# download fails, abort the process.
MAGISKBOOT_URL="https://github.com/Streep69/Patch-Recovery/raw/master/magiskboot"
curl -Ls -o magiskboot "$MAGISKBOOT_URL"
chmod +x magiskboot

# Execute the fastbootd patch and fstab cleaner scripts
bash script1.sh
bash script2.sh

# Copy the patched recovery image back to the original working directory
cp recovery.img "$OLDPWD/patched_recovery.img"

echo "Patched recovery image created at $OLDPWD/patched_recovery.img"