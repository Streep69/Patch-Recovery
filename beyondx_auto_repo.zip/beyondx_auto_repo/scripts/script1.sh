#!/usr/bin/env bash
# This script patches a Samsung recovery image to add fastbootd support.
# It is based on the script from Streep69/Patch-Recovery and uses MagiskBoot
# to unpack, modify and repack the ramdisk. The recovery image must be named
# recovery.img in the current working directory. After running, recovery.img
# will be replaced with a patched version that enables the fastbootd service.

set -euo pipefail

MAGISKBOOT="$(dirname "$0")/magiskboot"
IMG="recovery.img"

# Unpack the recovery image
"$MAGISKBOOT" --unpack "$IMG"

# Ensure the ramdisk contains a sbin directory for fastbootd
mkdir -p ramdisk/sbin

# Copy MagiskBoot binary into the ramdisk as fastbootd
cp "$MAGISKBOOT" ramdisk/sbin/fastbootd
# Strip debug symbols to reduce size; ignore errors if strip isn't available
strip --strip-all ramdisk/sbin/fastbootd 2>/dev/null || true

# Enable the ro.fastbootd.available property if not already present
grep -q "ro.fastbootd.available" ramdisk/default.prop || \
  echo "ro.fastbootd.available=1" >> ramdisk/default.prop

# Add a service entry for fastbootd to init.rc if one does not already exist
if ! grep -q "service fastbootd" ramdisk/init.rc; then
  cat >> ramdisk/init.rc <<'EOF'
service fastbootd /sbin/fastbootd
    class main
    disabled
    seclabel u:r:fastbootd:s0
EOF
fi

# Repack the modified ramdisk back into a recovery image
"$MAGISKBOOT" --repack "$IMG"

# Replace the original recovery image with the patched version
mv new-"$IMG" "$IMG"

echo "✓ fastbootd patch applied"