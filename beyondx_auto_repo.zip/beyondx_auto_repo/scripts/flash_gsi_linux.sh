#!/usr/bin/env bash
# Flash a Generic System Image (GSI) from fastbootd on Linux/macOS.
#
# Usage: ./flash_gsi_linux.sh path/to/gsi.img
#
# This script assumes the device is already in fastbootd mode. It will
# erase the system partition, flash the provided GSI image, perform a
# factory reset and reboot the device. For dynamic partition devices,
# fastbootd must be used instead of the bootloader fastboot.

set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 path/to/gsi.img"
  exit 1
fi

GSI_IMG="$1"

if [ ! -f "$GSI_IMG" ]; then
  echo "GSI image not found: $GSI_IMG"
  exit 1
fi

echo "Flashing GSI: $GSI_IMG"

# Display connected devices in fastboot mode
fastboot devices

# Erase the existing system partition
fastboot erase system || true

# Flash the new GSI to the system partition
fastboot flash system "$GSI_IMG"

# Wipe user data for a clean boot
fastboot -w

# Reboot the device
fastboot reboot

echo "✓ GSI flashed and device rebooting"