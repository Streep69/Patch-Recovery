#!/usr/bin/env python3
"""
Convert a TWRP image into an Odin-flashable tar archive with an MD5 footer.

Samsung Odin requires that the tar archive ends with a 32‑character
hexadecimal MD5 of the archive contents. This script takes a TWRP `.img`
file and produces `TWRP_beyondx.tar.md5` in the current working directory.

Usage:
    python3 make_twrp_tar.py /path/to/twrp.img

The resulting tar (without the MD5 suffix) and the tar.md5 file will be
created in the current directory.
"""

import hashlib
import os
import sys
import tarfile

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: make_twrp_tar.py path/to/twrp.img")
        sys.exit(1)

    img_path = sys.argv[1]
    if not os.path.exists(img_path):
        print(f"File not found: {img_path}")
        sys.exit(1)

    # Create a tar archive containing the TWRP image renamed to recovery.img
    tar_name = "TWRP_beyondx.tar"
    with tarfile.open(tar_name, "w") as tar:
        tar.add(img_path, arcname="recovery.img")

    # Read the tar contents to compute its MD5 checksum
    with open(tar_name, "rb") as f:
        data = f.read()
    md5_hash = hashlib.md5(data).hexdigest()

    # Write the tar contents followed by the hex digest into the .tar.md5 file
    md5_file = tar_name + ".md5"
    with open(md5_file, "wb") as f:
        f.write(data)
        f.write(md5_hash.encode())

    print(f"Created {md5_file}")

if __name__ == "__main__":
    main()