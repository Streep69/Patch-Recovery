#!/usr/bin/env bash
# This script cleans the fstab entries in a Samsung recovery image. It removes
# AVB and other verification flags that can cause flashing failures on patched
# recoveries. The recovery image must be named recovery.img in the current
# working directory. After running, recovery.img will be replaced with a
# repacked version with cleaned fstab entries.

set -euo pipefail

MAGISKBOOT="$(dirname "$0")/magiskboot"
IMG="recovery.img"

# Unpack the recovery image
"$MAGISKBOOT" --unpack "$IMG"

# Find all files containing "fstab" in the ramdisk and clean verification flags
for f in $(grep -alR "fstab" ramdisk 2>/dev/null || true); do
  # Remove avb, verify, support_scfs and overlayfs flags from the fstab entries
  sed -Ei 's/,?(avb|verify|support_scfs|overlayfs)[^, ]*//g' "$f"
done

# Repack the modified ramdisk back into a recovery image
"$MAGISKBOOT" --repack "$IMG"

# Replace the original recovery image with the cleaned version
mv new-"$IMG" "$IMG"

echo "✓ fstab cleaned"