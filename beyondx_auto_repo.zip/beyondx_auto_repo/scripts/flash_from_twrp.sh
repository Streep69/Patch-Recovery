#!/usr/bin/env sh
# Flash a new TWRP image from within TWRP using dd.
#
# Usage: sh flash_from_twrp.sh /sdcard/Download/twrp.img
#
# This script writes the provided TWRP image to the recovery partition on
# Samsung S10 5G (beyondx) devices. It should be executed from a shell
# inside TWRP (via Advanced → Terminal or via ADB shell).

IMG="$1"

if [ -z "$IMG" ]; then
  echo "Usage: $0 /path/to/twrp.img"
  exit 1
fi

if [ ! -f "$IMG" ]; then
  echo "TWRP image not found: $IMG"
  exit 1
fi

echo "Flashing TWRP image $IMG to recovery partition..."

# Write the image to the recovery partition (device-specific path)
dd if="$IMG" of=/dev/block/platform/13d60000.ufs/by-name/recovery bs=8M

# Ensure all writes are flushed to disk
sync

# Reboot back into recovery
reboot recovery

echo "✓ TWRP flashed and rebooting to recovery"